<h1><center>Courses Offered</center></h1>
<div align="center">
<table width="725" height="346" border="1">
  <tbody>
    <tr>
      <td height="30" bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Course</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Intake</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Duration</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Other</b></font></center></td>
    </tr>
    <tr>
      <td colspan="4" bgcolor="#A1AAF3"><center><font size="+1"><b>Bachelor of Technology</b></font></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Computer Science</b></center></td>
      <td bgcolor="#97CDDB"><center><b>120</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Vocational Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Mechanical Enigineering</b></center></td>
      <td bgcolor="#97CDDB"><center><b>60</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Vocational Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Civil Engineering</b></center></td>
      <td bgcolor="#97CDDB"><center><b>120</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Field Training</b></center></td>
    </tr>
    <tr>
      <td bgcolor="#B4BEDC"><center><b>Electronics &amp; Communication</b></center></td>
      <td bgcolor="#97CDDB"><center><b>120</b></center></td>
      <td bgcolor="#B4BEDC"><center><b>4 Years</b></center></td>
      <td bgcolor="#97CDDB"><center><b>Company Visits</b></center></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;	</p>
<table width="725" height="246" border="1">
  <tbody>
    <tr>
      <td height="30" bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Course</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Intake</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Duration</b></font></center></td>
      <td bgcolor="#7179CF" style="color: #FFFFFF"><center><font size="+2"><b>Other</b></font></center></td>
    </tr>
    <tr>
      <td height="72" colspan="4" bgcolor="#A1AAF3"><center>
        <font size="+1"><b>Masters of Technology</b></font>
      </center></td>
    </tr>
    <tr>
      <td height="59" bgcolor="#B4BEDC"><center><b>Computer Science</b></center></td>
      <td bgcolor="#97CDDB"><center>
        <b>30</b>
      </center></td>
      <td bgcolor="#B4BEDC"><center>
        <b>2 Years</b>
      </center></td>
      <td bgcolor="#97CDDB"><center>
        <b>Foreign Trip &amp; Faculty Induction Programme</b>
      </center></td>
    </tr>
    <tr>
      <td height="51" bgcolor="#B4BEDC"><center><b>Mechanical Enigineering</b></center></td>
      <td bgcolor="#97CDDB"><center>
        <b>30</b>
      </center></td>
      <td bgcolor="#B4BEDC"><center>
        <b>2 Years</b>
      </center></td>
      <td bgcolor="#97CDDB"><center>
        <b>Vocational Training &amp; Foreign Trip</b>
      </center></td>
    </tr>
  </tbody>
</table>
</div>
