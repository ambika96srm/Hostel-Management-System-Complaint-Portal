<div align="center"><header> <h1><strong style="color: black">COMPLAINT LIST</strong></h1></header></div>
<br><br><br>
<div align="center">

<?php
require ('config.php');
$result = mysqli_query($con,"SELECT * FROM complaint");

echo 
"<table border='1' cellspacing='5' cellpadding='35' width='45'>
<tr>
<th>Reg NO</th>
<th>Hostel Name</th>
<th>Complaint</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['Regno'] . "</td>";
echo "<td>" . $row['Hostel'] . "</td>";
echo "<td>" . $row['Comp'] . "</td>";
echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>
</div>