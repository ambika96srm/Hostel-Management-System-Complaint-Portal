<?php

require('config.php');
$r=$h=$c="";

    $r = $_POST['regno'];

    $h = $_POST['hos'];


    $c = $_POST['comp'];


$sql="INSERT INTO complaint(Regno,Hostel,Comp) VALUES ('$r', '$h','$c')";
mysqli_query($con,$sql);
  //mkdir("images/".$_POST['umail']);
  //move_uploaded_file($_FILES['file']['tmp_name'],"images/".$_POST['umail']."/".$_FILES['file']['name']);
  

?>




<html>


<div align="center">
<form method="post" action="complainlogin.php">
<table width="1067" height="493" border="1">
  <tbody>
    <tr>
      <td width="1057" height="59" bgcolor="#4D4C94"><center>
        <h1><strong style="color: #FFFFFF">COMPLAINT PORTAL</strong></h1>
      </center></td>
    </tr>
    <tr>
      <th height="426" bgcolor="#969BEF">
      <fieldset style="display:inline-flex"><legend><font size="+1">Enter Details</font></legend>
      <p>Register Number : <input type="text" name="regno" ><br>
      <p>Hostel Name :<select style="max-width:90%;" id="c" name="hos">
  <option value="Mullai" >Mullai</option>
  <option value="Thamarai" >Thamaraii</option>
  <option value="Kalpana Chawla">Kalpana Chawla</option>
  <option value="ESQ">ESQ</option></select>
  <p>Enter complaint: <textarea cols="12" rows="5" name="comp" ></textarea>
      </fieldset>
      </th>
    </tr>

  </tbody>
</table>
<tr><p><input type="submit" value="Enter complaint" name="admlogin">&nbsp;<input type="reset" value="Reset"></p></tr>
</form>
</div>
</html>